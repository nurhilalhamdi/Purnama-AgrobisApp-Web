<?php
defined('BASEPATH') or exit('No direct script access allowed');

// This can be removed if you use __autoload() in config.php OR use Modular Extensions
/** @noinspection PhpIncludeInspection */
require APPPATH . '/libraries/REST_Controller.php';

use PhpParser\Node\Stmt\Else_;
use Restserver\Libraries\REST_Controller;

class CekHarian extends REST_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('CekHarian_Model', 'inputharian');
    }


    public function index_get()
    {
        # code...


        $id = $this->get('id');

        if ($id === null) {
            # code...
            $getCekharian = $this->inputharian->getDataCekharian();
        } else {
            $getCekharian = $this->inputharian->getDataCekharian($id);
        }



        if ($getCekharian) {
            # code...

            $this->response([
                'status' => TRUE,
                'data' => $getCekharian
            ], REST_Controller::HTTP_OK);
        } else {
            # code...

            $this->response([
                'status' => FALSE,
                'data' => 'Tidak Ada Data Cek Harian'
            ], REST_Controller::HTTP_NOT_FOUND);
        }
    }

    public function index_post()
    {
        $this->load->library('upload');

        if ($_FILES['file']['size'] > 0) {
            # code...
            $config['upload_path'] = './Test/CekHarianFile';
            $config['allowed_types'] = 'gif|jpg|png';
            $config['max_width'] = 10000;
            $config['max_height'] = 10000;
            $config['overwrite'] = TRUE;
            $config['max_filename'] = 25;

            $this->upload->initialize($config);

            if (!$this->upload->do_upload('file')) {
                # code...
                $error = $this->upload->display_errors();
                $this->set_response([
                    'status' => false,
                    'message' => $error
                ], REST_Controller::HTTP_NOT_FOUND);
            } else {
                # code...


                $photo = $this->upload->file_name;

                $url = 'http://localhost/PurnamaCI/Test/CekHarianFile/' . $photo;
                $filename = substr($url, strrpos($url, '/') + 1);
                file_put_contents('./Test/CekHarianFile/' . $filename, file_get_contents($url));

                $data = [
                    'tanggal_waktu_cek' => $this->post('tanggal_waktu_cek'),
                    'nama_petugas' => $this->post('nama_petugas'),
                    'alamat_kandang' => $this->post('alamat_kandang'),
                    'kode_kandang' => $this->post('kode_kandang'),
                    'kode_blok' => $this->post('kode_blok'),
                    'jumlah_ayam' => $this->post('jumlah_ayam'),
                    'umur_ayam' => $this->post('umur_ayam'),
                    'tanggal_ayam_masuk' => $this->post('tanggal_ayam_masuk'),
                    'kondisi_ayam' => $this->post('kondisi_ayam'),
                    'jumlah_ayam_sakit' => $this->post('jumlah_ayam_sakit'),
                    'gejala_sakit' => $this->post('gejala_sakit'),
                    'jam_pakan' => $this->post('jam_pakan'),
                    'jam_ganti_minum' => $this->post('jam_ganti_minum'),
                    'jam_ganti_vitamin' => $this->post('jam_ganti_vitamin'),
                    'jumlah_pakan' => $this->post('jumlah_pakan'),
                    'latitude' => $this->post('latitude'),
                    'longitude' => $this->post('longitude'),
                    'file' => $url,
                    'id_user' => $this->post('id_user'),
                ];

                $insert = $this->inputharian->cekharianInput($data);

                if ($insert) {
                    # code...
                    $status = 'Ok';
                }
            }
        } else {
            $status = 'Select File';
        }
        echo json_encode(array('response' => $status));
    }
}

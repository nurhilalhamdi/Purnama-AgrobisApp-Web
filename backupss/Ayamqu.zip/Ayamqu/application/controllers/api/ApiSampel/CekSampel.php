<?php
defined('BASEPATH') or exit('No direct script access allowed');

// This can be removed if you use __autoload() in config.php OR use Modular Extensions
/** @noinspection PhpIncludeInspection */
require APPPATH . '/libraries/REST_Controller.php';

use PhpParser\Node\Stmt\Else_;
use Restserver\Libraries\REST_Controller;

class CekSampel extends REST_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('CekSampel_Model', 'inputsampel');
    }


    public function index_get()
    {
        # code...


        $id = $this->get('id_user');

        if ($id === null) {
            # code...
            $getCeksampel = $this->inputsampel->getDataCeksampel();
        } else {
            $getCeksampel = $this->inputsampel->getDataCeksampel($id);
        }



        if ($getCeksampel) {
            # code...

            // if (!empty($getCeksampel)) {
            # code...
            // $this->response(array("result" => $getCeksampel, 200));

            $status = 'Ok';
            echo json_encode(array("status" => $status, "result" => $getCeksampel, 200));
            // }else{
            //     $status = 'Data Sampel Tidak Ditemukan';
            //     $this->response(array("result" => $status, 200));
            // }

            // $this->response([
            //     'status' => TRUE,
            //     'data' => $getCeksampel
            // ], REST_Controller::HTTP_OK);
        } else {
            # code...

            // $this->response(array("result" => "Fail"));
            $status = 'Fail';
            echo json_encode(array('status' => $status));

            // $this->response([
            //     'status' => FALSE,
            //     'data' => 'Tidak Ada Data Cek Sampel'
            // ], REST_Controller::HTTP_NOT_FOUND);
        }
    }

    public function index_post()
    {
        $this->load->library('upload');
        if ($_FILES['file']['size'] > 0) {
            # code...
            $config['upload_path'] = './Test/CekSampelFile/';
            $config['allowed_types'] = 'gif|jpg|png';
            $config['max_width'] = 10000;
            $config['max_height'] = 10000;
            $config['overwrite'] = TRUE;
            $config['max_filename'] = 25;
            $this->upload->initialize($config);
            if (!$this->upload->do_upload('file')) {

                $error = $this->upload->display_errors();
                $this->set_response([
                    'status' => false,
                    'message' => $error
                ], REST_Controller::HTTP_NOT_FOUND);
            } else {
                $photo = $this->upload->file_name;
                $url = 'http://localhost/PurnamaCI/Test/CekSampelFile/' . $photo;
                $filename = substr($url, strrpos($url, '/') + 1);
                file_put_contents('./Test/CekSampelFile/' . $filename, file_get_contents($url));

                $data = [
                    'tanggal_waktu_sampel' => $this->post('tanggal_waktu_sampel'),
                    'nama' => $this->post('nama'),
                    'kode_kandang' => $this->post('kode_kandang'),
                    'kode_blok' => $this->post('kode_blok'),
                    'jumlah_ayam' => $this->post('jumlah_ayam'),
                    'umur_ayam' => $this->post('umur_ayam'),
                    'kondisi_ayam' => $this->post('kondisi_ayam'),
                    'bobot_rata_rata' => $this->post('bobot_rata_rata'),
                    'jenis_ayam_sampel' => $this->post('jenis_ayam_sampel'),
                    'bobot_ayam_sampel' => $this->post('bobot_ayam_sampel'),
                    'jumlah_ayam_sampel' => $this->post('jumlah_ayam_sampel'),
                    'latitude' => $this->post('latitude'),
                    'longitude' => $this->post('longitude'),
                    'file' => $url,
                    'id_user' => $this->post('id_user'),
                    'id_kandang' => $this->post('id_kandang')
                ];

                $insert = $this->inputsampel->ceksampelInput($data);

                if ($insert) {
                    # code...
                    $status = 'Berhasil';
                }
            }
        } else {
            $status = 'Select File';
        }
        echo json_encode(array('response' => $status));
    }
}

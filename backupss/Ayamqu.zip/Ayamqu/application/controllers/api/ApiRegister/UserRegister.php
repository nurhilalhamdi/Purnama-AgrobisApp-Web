<?php

defined('BASEPATH') or exit('No direct script access allowed');

// This can be removed if you use __autoload() in config.php OR use Modular Extensions
/** @noinspection PhpIncludeInspection */
require APPPATH . '/libraries/REST_Controller.php';

use PhpParser\Node\Stmt\Else_;
use Restserver\Libraries\REST_Controller;

class UserRegister extends REST_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('User_Model', 'login');
    }

    public function index_post()
    {
        $nama = strip_tags($this->post('nama'));
        $username = strip_tags($this->post('username'));
        $alamat = strip_tags($this->post('alamat'));
        $email = strip_tags($this->post('email'));
        $no_telephone = strip_tags($this->post('no_telephone'));
        $password = strip_tags($this->post('password'));

        $con['returnType'] = 'count';
        $con['conditions'] = array(
            'username' => $username,
        );
        $userCount = $this->login->getRows($con);

        if ($userCount > 0) {
            # code...
            $status = 'Exist';
        } else {
            $data = array(
                'nama' => $nama,
                'username' => $username,
                'alamat' => $alamat,
                'email' => $email,
                'no_telephone' => $no_telephone,
                'password' => md5($password),
                'status' => 'Aktif',
            );

            $insert = $this->login->UserRegister($data);
            if ($insert) {
                # code...
                $status = 'Ok';
            } else {
                $status = 'Error';
            }
        }
        echo json_encode(array('response' => $status));
    }
}

<?php
defined('BASEPATH') or exit('No direct script access allowed');

// This can be removed if you use __autoload() in config.php OR use Modular Extensions
/** @noinspection PhpIncludeInspection */
require APPPATH . '/libraries/REST_Controller.php';

use PhpParser\Node\Stmt\Else_;
use Restserver\Libraries\REST_Controller;

class Kandang extends REST_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Kandang_Model', 'kandangmodel');
    }


    public function index_get()
    {
        # code...


        $id_user = $this->get('id_user');

        if ($id_user === null) {
            # code...
            $getKandang = $this->kandangmodel->getDataTambahKandang();
        } else {
            $getKandang = $this->kandangmodel->getDataTambahKandang($id_user);
        }



        if ($getKandang) {
            # code...


            $status = 'Ok';
            echo json_encode(array("status" => $status, "result" => $getKandang, 200));
        } else {
            # code...

            $status = 'Fail';
            echo json_encode(array('status' => $status));
        }
    }

    public function index_post()
    {
        $data = [
            'alamat_kandang' => $this->post('alamat_kandang'),
            'kode_kandang' => $this->post('kode_kandang'),
            'kode_blok' => $this->post('kode_blok'),
            'jenis_kandang' => $this->post('jenis_kandang'),
            'id_user' => $this->post('id_user'),
        ];

        $insert = $this->kandangmodel->tambahKandangInput($data);

        if ($insert) {
            # code...
            // $status = 'Berhasil';
            $status = 'Ok';
            echo json_encode(array("status" => $status, 200));
        } else {
            $status = 'Gagal';
            echo json_encode(array("status" => $status));
        }
        // echo json_encode(array('response' => $status));
    }
}

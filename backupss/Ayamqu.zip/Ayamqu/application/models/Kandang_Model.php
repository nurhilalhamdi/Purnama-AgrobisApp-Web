<?php

class Kandang_Model extends CI_Model
{

    public function tambahKandangInput($data)
    {

        $this->db->insert('tabel_kandang', $data);
        return $this->db->affected_rows();
    }


    public function getDataTambahKandang($id_user = null)
    {


        if ($id_user === null) {
            # code...
            return $this->db->get('tabel_kandang')->result_array();
        } else {
            return $this->db->get_where('tabel_kandang', ['id_user' => $id_user])->result_array();
        }
    }
}

<?php

class CekHarian_Model extends CI_Model
{

    public function cekharianInput($data)
    {

        $this->db->insert('tabel_cekharian', $data);
        return $this->db->affected_rows();
    }


    public function getDataCekharian($id = null)
    {


        if ($id === null) {
            # code...
            return $this->db->get('tabel_cekharian')->result_array();
        } else {
            return $this->db->get_where('tabel_cekharian', ['id' => $id])->result_array();
        }
    }
}

<?php

class CekSampel_Model extends CI_Model
{

    public function ceksampelInput($data)
    {

        $this->db->insert('tabel_ceksampel', $data);
        return $this->db->affected_rows();
    }


    public function getDataCeksampel($id = null)
    {


        if ($id === null) {
            # code...
            return $this->db->get('tabel_ceksampel')->result_array();
        } else {
            return $this->db->get_where('tabel_ceksampel', ['id_user' => $id])->result_array();
        }
    }
}
